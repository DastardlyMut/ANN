% risk_sim.m
% Author: Sean Devonport
% Script that plots trends in the cancer data.
%%
clc;clear;close all
%%
